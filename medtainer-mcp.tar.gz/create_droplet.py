#!/usr/bin/env python3
"""
Create DigitalOcean Droplet for MedTainer MCP

This script creates a DigitalOcean droplet with password authentication enabled.
After creation, use the manual deployment script (deploy.sh) to deploy the application.

Usage:
    python3 create_droplet.py
"""

import os
import sys
import time
import httpx
from pathlib import Path

# DigitalOcean API Configuration
DO_API_TOKEN = os.getenv("DIGITALOCEAN_API_TOKEN", "dop_v1_e51f560d3fcdbfea2273059609cf63f86cef71118358d7afa996b0464e5fdd2f")
DO_BASE_URL = "https://api.digitalocean.com/v2"

# Droplet Configuration
ROOT_PASSWORD = "MedT@iner2024!Secure"  # Strong password for root access

# Cloud-init user data to enable password authentication
USER_DATA = f"""#cloud-config
chpasswd:
  list: |
    root:{ROOT_PASSWORD}
  expire: False
ssh_pwauth: True
"""

DROPLET_CONFIG = {
    "name": "medtainer-mcp",
    "region": "sfo3",
    "size": "s-2vcpu-4gb",
    "image": "ubuntu-22-04-x64",
    "tags": ["medtainer", "mcp", "production"],
    "monitoring": True,
    "ipv6": False,
    "backups": False,
    "user_data": USER_DATA,
}


def create_droplet():
    """Create a new DigitalOcean droplet."""
    print("\n" + "="*60)
    print("🚀 Creating DigitalOcean Droplet")
    print("="*60 + "\n")

    headers = {
        "Authorization": f"Bearer {DO_API_TOKEN}",
        "Content-Type": "application/json"
    }

    print("📝 Droplet Configuration:")
    print(f"   Name:   {DROPLET_CONFIG['name']}")
    print(f"   Region: {DROPLET_CONFIG['region']}")
    print(f"   Size:   {DROPLET_CONFIG['size']}")
    print(f"   Image:  {DROPLET_CONFIG['image']}")
    print()

    # Create droplet
    print("🚀 Creating droplet...")
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{DO_BASE_URL}/droplets",
                headers=headers,
                json=DROPLET_CONFIG
            )
            response.raise_for_status()
            result = response.json()
    except Exception as e:
        print(f"❌ Failed to create droplet: {e}")
        sys.exit(1)

    droplet = result.get("droplet", {})
    droplet_id = droplet["id"]
    print(f"✅ Droplet created! ID: {droplet_id}")
    print(f"   Status: {droplet['status']}")
    print()

    # Wait for droplet to be active
    print("⏳ Waiting for droplet to be active...")
    start_time = time.time()
    max_wait = 300

    while time.time() - start_time < max_wait:
        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.get(
                    f"{DO_BASE_URL}/droplets/{droplet_id}",
                    headers=headers
                )
                response.raise_for_status()
                result = response.json()
        except Exception as e:
            print(f"   Error checking status: {e}")
            time.sleep(5)
            continue

        droplet = result.get("droplet", {})
        status = droplet.get("status")
        elapsed = int(time.time() - start_time)

        print(f"   Status: {status} ({elapsed}s)", end="\r")

        if status == "active":
            # Get IP address
            networks = droplet.get("networks", {})
            v4_networks = networks.get("v4", [])
            if v4_networks:
                droplet_ip = v4_networks[0]["ip_address"]
                print(f"\n✅ Droplet is active! IP: {droplet_ip}")
                print()

                # Wait a bit longer for cloud-init to finish
                print("⏳ Waiting for cloud-init to configure SSH (60s)...")
                time.sleep(60)

                # Print deployment instructions
                print_deployment_info(droplet_id, droplet_ip)
                return

        time.sleep(5)

    print("\n❌ Timeout waiting for droplet to be active")
    sys.exit(1)


def print_deployment_info(droplet_id, droplet_ip):
    """Print deployment instructions."""
    print("\n" + "="*60)
    print("✅ DROPLET READY FOR DEPLOYMENT")
    print("="*60)
    print(f"""
Droplet Information:
  ID:        {droplet_id}
  IP:        {droplet_ip}
  Password:  {ROOT_PASSWORD}

Next Steps:

1. Test SSH connection:
   ssh root@{droplet_ip}
   (Use password: {ROOT_PASSWORD})

2. Deploy using the manual script:
   ./deploy.sh

   When prompted:
   - Enter droplet IP: {droplet_ip}
   - Choose: 1 (Initial deployment)
   - Enter password when prompted: {ROOT_PASSWORD}

3. OR follow manual deployment steps from DEPLOY_NOW.md

4. After deployment, update mcp_stdio_bridge.py:
   Change SERVER_URL to: http://{droplet_ip}:8000

5. Test the server:
   curl http://{droplet_ip}:8000/health

Server Details Saved:
  Desktop/MCP_SERVER_INFO.txt
    """)

    # Save to file
    info_file = Path.home() / "Desktop" / "MCP_SERVER_INFO.txt"
    info_file.write_text(f"""MedTainer MCP Server - DigitalOcean Droplet Created

Droplet ID: {droplet_id}
IP Address: {droplet_ip}
Root Password: {ROOT_PASSWORD}

SSH Access:
  ssh root@{droplet_ip}
  Password: {ROOT_PASSWORD}

Deployment Steps:

1. Deploy using deploy.sh:
   cd "/Users/johnberfelo/AI Projects/MedTainer MCP"
   ./deploy.sh
   - Enter IP: {droplet_ip}
   - Choose: 1 (Initial deployment)
   - Password: {ROOT_PASSWORD}

2. After deployment, test:
   curl http://{droplet_ip}:8000/health

3. Update mcp_stdio_bridge.py:
   SERVER_URL = "http://{droplet_ip}:8000"

4. Restart Claude Desktop

Cost: $24/month

Created: {time.strftime('%Y-%m-%d %H:%M:%S')}
""")

    print(f"📄 Connection info saved to: {info_file}\n")


def main():
    """Main entry point."""
    if not DO_API_TOKEN:
        print("❌ Error: DIGITALOCEAN_API_TOKEN not found")
        print("   Set it in .env or export it as an environment variable")
        sys.exit(1)

    try:
        create_droplet()
        print("✅ Done! Follow the steps above to complete deployment.\n")
    except KeyboardInterrupt:
        print("\n\n❌ Cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
