from app.mcp.ecosystems.bootstrap import register_all_bundles
from app.mcp.tool_registry import registry

register_all_bundles(registry)
