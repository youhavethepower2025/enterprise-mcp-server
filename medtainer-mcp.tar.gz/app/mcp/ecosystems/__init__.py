from .bootstrap import register_all_bundles

__all__ = ["register_all_bundles"]
