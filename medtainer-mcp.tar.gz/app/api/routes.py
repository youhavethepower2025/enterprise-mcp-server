from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, HTTPException, Query, Depends, BackgroundTasks
from sqlalchemy.orm import Session

from app.core.config import settings
from app.mcp.tool_registry import ToolNotFoundError, registry
from app.db.session import get_db
from app.db.models import ToolExecution, GoDaddySyncHistory
from app.services import run_weekly_sync
from app.services.context_service import ContextService
from app.scheduler import get_scheduler_status, trigger_sync_now

router = APIRouter()


@router.get("/health")
def health_check() -> dict:
    return {
        "app": settings.app_name,
        "environment": settings.environment,
        "status": "ok",
    }


@router.get("/mcp/tools")
def list_tools(ecosystem: Optional[str] = Query(default=None)) -> dict:
    """Expose registered tools so agents can introspect capabilities."""
    # Only show tools from configured ecosystems
    # Filter to GoHighLevel, GoDaddy, and DigitalOcean (the ones we've set up)
    enabled_ecosystems = {"gohighlevel", "godaddy", "digitalocean"}

    tools = registry.list_tools(ecosystem=ecosystem)

    # Filter to only enabled ecosystems
    filtered_tools = [
        tool for tool in tools
        if tool.get("ecosystem") in enabled_ecosystems
    ]

    return {
        "count": len(filtered_tools),
        "tools": filtered_tools,
    }


@router.post("/mcp/run/{tool_name}")
def run_tool(tool_name: str, params: Dict[str, Any] = Body(default_factory=dict)) -> dict:
    try:
        result = registry.execute(tool_name, params)
    except ToolNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return result.model_dump()


@router.get("/mcp/logs")
def get_recent_logs(
    limit: int = Query(default=10, ge=1, le=100),
    tool_name: Optional[str] = Query(default=None),
    db: Session = Depends(get_db)
) -> dict:
    """
    Get recent tool execution logs from the database.
    
    This endpoint allows you to see what tools have been executed,
    with what parameters, and what the results were.
    
    Args:
        limit: Maximum number of logs to return (1-100, default 10)
        tool_name: Optional filter by specific tool name
        db: Database session (injected)
    
    Returns:
        Dictionary with count and list of execution logs
    """
    query = db.query(ToolExecution)
    
    if tool_name:
        query = query.filter(ToolExecution.tool_name == tool_name)
    
    executions = query.order_by(ToolExecution.timestamp.desc()).limit(limit).all()
    
    return {
        "count": len(executions),
        "limit": limit,
        "tool_name_filter": tool_name,
        "logs": [
            {
                "id": exec.id,
                "timestamp": exec.timestamp.isoformat() if exec.timestamp else None,
                "tool_name": exec.tool_name,
                "params": exec.params,
                "duration_ms": exec.duration_ms,
                "status": exec.status,
                "error_message": exec.error_message,
                "source": exec.source,
            }
            for exec in executions
        ]
    }


# =============================================================================
# GODADDY SYNC ENDPOINTS
# =============================================================================

@router.post("/godaddy/sync")
def trigger_godaddy_sync(background_tasks: BackgroundTasks) -> dict:
    """
    Manually trigger a GoDaddy cloud environment sync.

    This will sync:
    - All domains (registration info, expiration dates)
    - DNS records for each active domain
    - MX records (email configuration)
    - Subdomains (available for email addresses)
    - Contact information

    The sync runs in the background and typically takes 1-3 minutes
    depending on the number of domains.

    Returns:
        Message confirming sync has been triggered
    """
    background_tasks.add_task(run_weekly_sync)

    return {
        "status": "ok",
        "message": "GoDaddy sync triggered successfully",
        "note": "Sync is running in the background. Check /godaddy/sync/status for progress."
    }


@router.get("/godaddy/sync/status")
def get_godaddy_sync_status(
    limit: int = Query(default=5, ge=1, le=50),
    db: Session = Depends(get_db)
) -> dict:
    """
    Get the status of recent GoDaddy sync operations.

    Shows:
    - Recent sync history with timestamps
    - Number of domains and DNS records synced
    - Error counts and messages
    - Sync duration

    Args:
        limit: Maximum number of sync records to return (default 5)
        db: Database session (injected)

    Returns:
        Sync history and scheduler status
    """
    # Get recent sync history
    sync_history = db.query(GoDaddySyncHistory).order_by(
        GoDaddySyncHistory.sync_started_at.desc()
    ).limit(limit).all()

    # Get scheduler status
    scheduler_status = get_scheduler_status()

    return {
        "scheduler": scheduler_status,
        "recent_syncs": [
            {
                "id": sync.id,
                "started_at": sync.sync_started_at.isoformat() if sync.sync_started_at else None,
                "completed_at": sync.sync_completed_at.isoformat() if sync.sync_completed_at else None,
                "status": sync.sync_status,
                "domains_synced": sync.domains_synced,
                "dns_records_synced": sync.dns_records_synced,
                "errors_count": sync.errors_count,
                "duration_seconds": sync.duration_seconds,
                "error_message": sync.error_message
            }
            for sync in sync_history
        ]
    }


@router.get("/godaddy/domains/summary")
def get_godaddy_domains_summary(db: Session = Depends(get_db)) -> dict:
    """
    Get a summary of all GoDaddy domains and their status.

    Returns:
    - Total domains count
    - Active domains count
    - Cancelled/expired domains count
    - Domains expiring soon (within 90 days)

    Returns:
        Domain statistics summary
    """
    from app.db.models import GoDaddyDomain
    from sqlalchemy import func
    from datetime import datetime, timedelta

    # Count domains by status
    status_counts = db.query(
        GoDaddyDomain.status,
        func.count(GoDaddyDomain.domain_id).label('count')
    ).group_by(GoDaddyDomain.status).all()

    # Count domains expiring soon (within 90 days)
    expiring_soon_count = db.query(func.count(GoDaddyDomain.domain_id)).filter(
        GoDaddyDomain.status == 'ACTIVE',
        GoDaddyDomain.expires < datetime.utcnow() + timedelta(days=90)
    ).scalar()

    # Get last sync time
    last_sync = db.query(GoDaddySyncHistory).filter(
        GoDaddySyncHistory.sync_status == 'completed'
    ).order_by(GoDaddySyncHistory.sync_completed_at.desc()).first()

    return {
        "total_domains": sum(count for _, count in status_counts),
        "status_breakdown": {status: count for status, count in status_counts},
        "expiring_soon_90_days": expiring_soon_count,
        "last_synced_at": last_sync.sync_completed_at.isoformat() if last_sync and last_sync.sync_completed_at else None,
        "data_freshness": "Live data from GoDaddy API" if not last_sync else f"Synced {last_sync.sync_completed_at.isoformat()}"
    }

# === MCP Context Engineering Endpoints ===

@router.get("/mcp/resources")
def list_resources(db: Session = Depends(get_db)) -> dict:
    """
    List available context resources for AI agents.
    
    Resources provide automatic context that agents can read
    without explicit tool calls, enabling proactive guidance.
    """
    context_service = ContextService(db)
    resources = context_service.get_resources()
    return {
        "resources": resources
    }


@router.get("/mcp/resources/read")
def read_resource(uri: str = Query(...), db: Session = Depends(get_db)) -> dict:
    """
    Read the content of a specific resource.
    
    Args:
        uri: The resource URI (e.g., business://medtainer/dashboard)
    """
    context_service = ContextService(db)
    return context_service.read_resource(uri)


@router.get("/mcp/prompts")
def list_prompts(db: Session = Depends(get_db)) -> dict:
    """
    List available guided prompts for AI agents.
    
    Prompts are pre-built conversation starters that help users
    interact with the system more effectively.
    """
    context_service = ContextService(db)
    prompts = context_service.get_prompts()
    return {
        "prompts": prompts
    }


@router.post("/mcp/prompts/get")
def get_prompt(
    body: Dict[str, Any] = Body(...),
    db: Session = Depends(get_db)
) -> dict:
    """
    Get a specific prompt with its messages.
    
    Args:
        body: Dictionary with 'name' and 'arguments'
    """
    context_service = ContextService(db)
    name = body.get("name", "")
    arguments = body.get("arguments", {})
    return context_service.get_prompt(name, arguments)
