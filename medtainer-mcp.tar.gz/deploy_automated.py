#!/usr/bin/env python3
"""
Fully Automated DigitalOcean Deployment Script

This script uses the DigitalOcean API to:
1. Create a new droplet
2. Wait for it to be ready
3. Set up Docker and dependencies
4. Deploy the MedTainer MCP application
5. Return connection info for developer access

Usage:
    python3 deploy_automated.py
"""

import os
import sys
import time
import json
import subprocess
import httpx
from pathlib import Path
from typing import Dict, Any, Optional

# DigitalOcean API Configuration
DO_API_TOKEN = os.getenv("DIGITALOCEAN_API_TOKEN", "dop_v1_e51f560d3fcdbfea2273059609cf63f86cef71118358d7afa996b0464e5fdd2f")
DO_BASE_URL = "https://api.digitalocean.com/v2"

# Droplet Configuration
ROOT_PASSWORD = "MedT@iner2024!Secure"  # Strong password for root access

# Cloud-init user data to enable password authentication
USER_DATA = f"""#cloud-config
chpasswd:
  list: |
    root:{ROOT_PASSWORD}
  expire: False
ssh_pwauth: True
"""

DROPLET_CONFIG = {
    "name": "medtainer-mcp",
    "region": "sfo3",
    "size": "s-2vcpu-4gb",
    "image": "ubuntu-22-04-x64",
    "tags": ["medtainer", "mcp", "production"],
    "monitoring": True,
    "ipv6": False,
    "backups": False,
    "user_data": USER_DATA,
}

class DigitalOceanDeployer:
    """Automated deployment to DigitalOcean."""

    def __init__(self, api_token: str):
        self.api_token = api_token
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }
        self.droplet_id = None
        self.droplet_ip = None

    def _request(self, method: str, endpoint: str, json_data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make HTTP request to DigitalOcean API."""
        url = f"{DO_BASE_URL}{endpoint}"

        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    json=json_data
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            print(f"❌ API error: {e.response.status_code} - {e.response.text}")
            raise
        except Exception as e:
            print(f"❌ Request failed: {str(e)}")
            raise

    def create_droplet(self) -> Dict[str, Any]:
        """Create a new droplet."""
        print("🚀 Creating DigitalOcean droplet...")
        print(f"   Name: {DROPLET_CONFIG['name']}")
        print(f"   Region: {DROPLET_CONFIG['region']}")
        print(f"   Size: {DROPLET_CONFIG['size']}")
        print(f"   Image: {DROPLET_CONFIG['image']}")

        response = self._request("POST", "/droplets", json_data=DROPLET_CONFIG)
        droplet = response.get("droplet", {})

        self.droplet_id = droplet["id"]
        print(f"✅ Droplet created! ID: {self.droplet_id}")
        print(f"   Status: {droplet['status']}")

        return droplet

    def wait_for_droplet(self, max_wait: int = 300) -> str:
        """Wait for droplet to be active and get IP address."""
        print(f"⏳ Waiting for droplet to be active (max {max_wait}s)...")

        start_time = time.time()
        while time.time() - start_time < max_wait:
            response = self._request("GET", f"/droplets/{self.droplet_id}")
            droplet = response.get("droplet", {})
            status = droplet.get("status")

            print(f"   Status: {status}", end="\r")

            if status == "active":
                # Get IP address
                networks = droplet.get("networks", {})
                v4_networks = networks.get("v4", [])
                if v4_networks:
                    self.droplet_ip = v4_networks[0]["ip_address"]
                    print(f"\n✅ Droplet is active! IP: {self.droplet_ip}")
                    return self.droplet_ip

            time.sleep(5)

        raise TimeoutError(f"Droplet did not become active within {max_wait} seconds")

    def wait_for_ssh(self, max_wait: int = 180) -> bool:
        """Wait for SSH to be available."""
        print(f"⏳ Waiting for SSH to be available (max {max_wait}s)...")
        print(f"   Note: Cloud-init is setting up password authentication...")

        start_time = time.time()
        while time.time() - start_time < max_wait:
            elapsed = int(time.time() - start_time)
            print(f"   Waiting... ({elapsed}s)", end="\r")

            try:
                # Try to connect via SSH (will use password when prompted)
                result = subprocess.run(
                    ["ssh", "-o", "StrictHostKeyChecking=no", "-o", "ConnectTimeout=5",
                     "-o", "BatchMode=yes",  # Fail if password is needed (we'll check port instead)
                     f"root@{self.droplet_ip}", "echo 'SSH Ready'"],
                    capture_output=True,
                    timeout=10
                )

                # If we get permission denied, SSH is up (just needs password)
                if b"Permission denied" in result.stderr or b"SSH Ready" in result.stdout:
                    print(f"\n✅ SSH is ready! (after {elapsed}s)")
                    return True
            except subprocess.TimeoutExpired:
                pass
            except Exception:
                pass

            time.sleep(5)

        raise TimeoutError(f"SSH did not become available within {max_wait} seconds")

    def setup_server(self) -> bool:
        """Run initial server setup."""
        print("🔧 Setting up server (Docker, dependencies)...")

        setup_commands = """
        set -e
        apt update -qq
        apt upgrade -y -qq
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        apt install docker-compose -y -qq
        systemctl start docker
        systemctl enable docker
        adduser --disabled-password --gecos "" medtainer || true
        usermod -aG docker medtainer
        usermod -aG sudo medtainer
        mkdir -p /home/medtainer
        chown medtainer:medtainer /home/medtainer
        echo 'Server setup complete!'
        """

        try:
            result = subprocess.run(
                ["ssh", "-o", "StrictHostKeyChecking=no",
                 f"root@{self.droplet_ip}", setup_commands],
                capture_output=True,
                text=True,
                timeout=600
            )

            if result.returncode == 0:
                print("✅ Server setup complete!")
                return True
            else:
                print(f"❌ Server setup failed: {result.stderr}")
                return False
        except Exception as e:
            print(f"❌ Server setup error: {e}")
            return False

    def deploy_application(self) -> bool:
        """Deploy the MedTainer MCP application."""
        print("📦 Deploying application...")

        # Create tarball
        print("   Creating deployment package...")
        project_dir = Path(__file__).parent

        try:
            subprocess.run(
                [
                    "tar",
                    "--exclude=.venv",
                    "--exclude=__pycache__",
                    "--exclude=*.pyc",
                    "--exclude=.git",
                    "--exclude=*.log",
                    "--exclude=.DS_Store",
                    "--exclude=deploy_automated.py",
                    "-czf",
                    "/tmp/medtainer-mcp.tar.gz",
                    "-C",
                    str(project_dir),
                    "."
                ],
                check=True,
                capture_output=True
            )
            print("   ✅ Package created")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to create package: {e.stderr.decode()}")
            return False

        # Upload to server
        print("   Uploading to server...")
        try:
            subprocess.run(
                ["scp", "-o", "StrictHostKeyChecking=no",
                 "/tmp/medtainer-mcp.tar.gz",
                 f"medtainer@{self.droplet_ip}:~/"],
                check=True,
                capture_output=True
            )
            print("   ✅ Upload complete")
        except subprocess.CalledProcessError as e:
            print(f"❌ Upload failed: {e.stderr.decode()}")
            return False

        # Extract and start
        print("   Starting application...")
        deploy_commands = """
        set -e
        mkdir -p ~/medtainer-mcp
        tar -xzf medtainer-mcp.tar.gz -C ~/medtainer-mcp
        cd ~/medtainer-mcp
        docker-compose -f docker-compose.prod.yml up -d --build
        sleep 10
        docker-compose -f docker-compose.prod.yml ps
        echo 'Application deployed!'
        """

        try:
            result = subprocess.run(
                ["ssh", "-o", "StrictHostKeyChecking=no",
                 f"medtainer@{self.droplet_ip}", deploy_commands],
                capture_output=True,
                text=True,
                timeout=600
            )

            if result.returncode == 0:
                print("✅ Application deployed!")
                print(result.stdout)
                return True
            else:
                print(f"❌ Deployment failed: {result.stderr}")
                return False
        except Exception as e:
            print(f"❌ Deployment error: {e}")
            return False

    def verify_deployment(self) -> bool:
        """Verify the application is running."""
        print("🔍 Verifying deployment...")

        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.get(f"http://{self.droplet_ip}:8000/health")
                response.raise_for_status()
                data = response.json()

                print(f"✅ Health check passed!")
                print(f"   App: {data.get('app')}")
                print(f"   Environment: {data.get('environment')}")
                print(f"   Status: {data.get('status')}")
                return True
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return False

    def print_connection_info(self):
        """Print connection information for developer."""
        print("\n" + "="*60)
        print("🎉 DEPLOYMENT SUCCESSFUL!")
        print("="*60)
        print(f"""
MedTainer MCP Server Deployed

Server IP: {self.droplet_ip}
Server URL: http://{self.droplet_ip}:8000

API Endpoints:
  Health:    http://{self.droplet_ip}:8000/health
  Tools:     http://{self.droplet_ip}:8000/mcp/tools
  Run tool:  http://{self.droplet_ip}:8000/mcp/run/{{tool_name}}

SSH Access:
  User:      root
  Password:  {ROOT_PASSWORD}
  Command:   ssh root@{self.droplet_ip}

  (Use the password above when prompted)

Database Access:
  Command:   ssh medtainer@{self.droplet_ip} 'docker exec -it medtainer-postgres psql -U mcp medtainer'

View Logs:
  Command:   ssh medtainer@{self.droplet_ip} 'cd medtainer-mcp && docker-compose -f docker-compose.prod.yml logs -f'

Update Bridge for Business Owner:
  Edit:      /Users/johnberfelo/AI Projects/MedTainer MCP/mcp_stdio_bridge.py
  Change:    SERVER_URL = "http://{self.droplet_ip}:8000"

Cost: $24/month

Next Steps:
1. Update mcp_stdio_bridge.py with the server URL above
2. Restart Claude Desktop
3. Test with: "Show me my GoHighLevel contacts"
4. For developer: You can now access this server from your own computer
        """)

        # Save connection info to file
        info_file = Path.home() / "Desktop" / "MCP_SERVER_INFO.txt"
        info_file.write_text(f"""MedTainer MCP Server Deployed

Server IP: {self.droplet_ip}
Server URL: http://{self.droplet_ip}:8000

API Endpoints:
- Health: http://{self.droplet_ip}:8000/health
- Tools: http://{self.droplet_ip}:8000/mcp/tools
- Run tool: http://{self.droplet_ip}:8000/mcp/run/{{tool_name}}

SSH Access:
- User: medtainer
- Command: ssh medtainer@{self.droplet_ip}

Root SSH (if needed):
- User: root
- Command: ssh root@{self.droplet_ip}

Database:
- Access: ssh medtainer@{self.droplet_ip} 'docker exec -it medtainer-postgres psql -U mcp medtainer'

Logs:
- View: ssh medtainer@{self.droplet_ip} 'cd medtainer-mcp && docker-compose -f docker-compose.prod.yml logs -f'

To update code:
1. Make changes on your local computer
2. Run: python3 deploy_automated.py --update
3. Or use: ./deploy.sh and choose option 2

Cost: $24/month
""")
        print(f"\n📄 Connection info saved to: {info_file}")


def main():
    """Main deployment flow."""
    print("\n" + "="*60)
    print("🚀 MedTainer MCP - Automated DigitalOcean Deployment")
    print("="*60 + "\n")

    if not DO_API_TOKEN:
        print("❌ Error: DIGITALOCEAN_API_TOKEN not found")
        print("   Set it in .env or export it as an environment variable")
        sys.exit(1)

    deployer = DigitalOceanDeployer(DO_API_TOKEN)

    try:
        # Step 1: Create droplet
        deployer.create_droplet()

        # Step 2: Wait for droplet to be active
        deployer.wait_for_droplet()

        # Step 3: Wait for SSH
        deployer.wait_for_ssh()

        # Step 4: Setup server
        if not deployer.setup_server():
            print("❌ Server setup failed. Aborting.")
            sys.exit(1)

        # Step 5: Deploy application
        if not deployer.deploy_application():
            print("❌ Application deployment failed. Aborting.")
            sys.exit(1)

        # Step 6: Verify deployment
        time.sleep(10)  # Give the app a few seconds to fully start
        if not deployer.verify_deployment():
            print("⚠️  Warning: Health check failed. Application may still be starting.")
            print("   Wait 30 seconds and test manually:")
            print(f"   curl http://{deployer.droplet_ip}:8000/health")

        # Step 7: Print connection info
        deployer.print_connection_info()

        print("\n✅ Deployment complete! 🎉\n")

    except KeyboardInterrupt:
        print("\n\n❌ Deployment cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
