#!/usr/bin/env python3
"""
Complete MedTainer MCP Deployment to DigitalOcean

This script completes the deployment after the droplet is created.
It uses SSH with password authentication to set up the server and deploy the application.

Usage:
    python3 complete_deployment.py <droplet_ip> <password>
"""

import sys
import time
import subprocess
from pathlib import Path
import paramiko

DROPLET_IP = "24.199.118.227"
ROOT_PASSWORD = "MedT@iner2024!Secure"


def run_ssh_command(ssh, command, description):
    """Run a command over SSH and print output."""
    print(f"   {description}...")
    stdin, stdout, stderr = ssh.exec_command(command, get_pty=True)

    # Wait for command to complete
    exit_status = stdout.channel.recv_exit_status()

    output = stdout.read().decode('utf-8')
    error = stderr.read().decode('utf-8')

    if exit_status == 0:
        print(f"   ✅ {description} complete")
        return True, output
    else:
        print(f"   ❌ {description} failed:")
        print(error)
        return False, error


def setup_server():
    """Set up the server with Docker and dependencies."""
    print("\n🔧 Setting up server...")

    # Create SSH client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        print(f"   Connecting to {DROPLET_IP}...")
        ssh.connect(DROPLET_IP, username='root', password=ROOT_PASSWORD, timeout=30)
        print("   ✅ Connected!")

        # Update system
        run_ssh_command(ssh, "apt update -qq", "Updating package lists")

        # Install Docker
        run_ssh_command(ssh,
            "curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh",
            "Installing Docker")

        # Install docker-compose
        run_ssh_command(ssh, "apt install docker-compose -y -qq", "Installing docker-compose")

        # Start Docker
        run_ssh_command(ssh, "systemctl start docker && systemctl enable docker", "Starting Docker")

        # Create medtainer user
        run_ssh_command(ssh,
            "adduser --disabled-password --gecos '' medtainer || true",
            "Creating medtainer user")

        # Add to docker group
        run_ssh_command(ssh, "usermod -aG docker medtainer", "Adding user to docker group")
        run_ssh_command(ssh, "usermod -aG sudo medtainer", "Adding user to sudo group")

        # Create home directory
        run_ssh_command(ssh,
            "mkdir -p /home/medtainer && chown medtainer:medtainer /home/medtainer",
            "Setting up home directory")

        print("✅ Server setup complete!\n")
        return True

    except Exception as e:
        print(f"❌ Setup failed: {e}")
        return False
    finally:
        ssh.close()


def deploy_application():
    """Deploy the MedTainer MCP application."""
    print("📦 Deploying application...")

    project_dir = Path(__file__).parent

    # Create tarball
    print("   Creating deployment package...")
    try:
        subprocess.run(
            [
                "tar",
                "--exclude=.venv",
                "--exclude=__pycache__",
                "--exclude=*.pyc",
                "--exclude=.git",
                "--exclude=*.log",
                "--exclude=.DS_Store",
                "--exclude=deploy_automated.py",
                "--exclude=create_droplet.py",
                "--exclude=complete_deployment.py",
                "-czf",
                "/tmp/medtainer-mcp.tar.gz",
                "-C",
                str(project_dir),
                "."
            ],
            check=True,
            capture_output=True
        )
        print("   ✅ Package created")
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to create package: {e.stderr.decode()}")
        return False

    # Upload via SFTP
    print(f"   Uploading to {DROPLET_IP}...")
    try:
        transport = paramiko.Transport((DROPLET_IP, 22))
        transport.connect(username='root', password=ROOT_PASSWORD)
        sftp = paramiko.SFTPClient.from_transport(transport)

        sftp.put("/tmp/medtainer-mcp.tar.gz", "/root/medtainer-mcp.tar.gz")
        print("   ✅ Upload complete")

        sftp.close()
        transport.close()
    except Exception as e:
        print(f"❌ Upload failed: {e}")
        return False

    # Extract and deploy
    print("   Starting application...")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        ssh.connect(DROPLET_IP, username='root', password=ROOT_PASSWORD, timeout=30)

        # Extract
        run_ssh_command(ssh,
            "mkdir -p /home/medtainer/medtainer-mcp && "
            "tar -xzf /root/medtainer-mcp.tar.gz -C /home/medtainer/medtainer-mcp",
            "Extracting files")

        # Set ownership
        run_ssh_command(ssh,
            "chown -R medtainer:medtainer /home/medtainer/medtainer-mcp",
            "Setting permissions")

        # Start application
        run_ssh_command(ssh,
            "cd /home/medtainer/medtainer-mcp && "
            "docker-compose -f docker-compose.prod.yml up -d --build",
            "Starting containers (this may take a few minutes)")

        print("✅ Application deployed!\n")
        return True

    except Exception as e:
        print(f"❌ Deployment failed: {e}")
        return False
    finally:
        ssh.close()


def verify_deployment():
    """Verify the application is running."""
    print("🔍 Verifying deployment...")
    print("   Waiting for application to start (30s)...")
    time.sleep(30)

    try:
        import httpx
        with httpx.Client(timeout=10.0) as client:
            response = client.get(f"http://{DROPLET_IP}:8000/health")
            response.raise_for_status()
            data = response.json()

            print(f"✅ Health check passed!")
            print(f"   App: {data.get('app')}")
            print(f"   Environment: {data.get('environment')}")
            print(f"   Status: {data.get('status')}\n")
            return True
    except Exception as e:
        print(f"⚠️  Health check failed: {e}")
        print(f"   The application may still be starting.")
        print(f"   Wait a minute and test manually: curl http://{DROPLET_IP}:8000/health\n")
        return False


def print_success_info():
    """Print success information."""
    print("=" * 60)
    print("🎉 DEPLOYMENT SUCCESSFUL!")
    print("=" * 60)
    print(f"""
MedTainer MCP Server Deployed

Server IP: {DROPLET_IP}
Server URL: http://{DROPLET_IP}:8000

API Endpoints:
  Health:    http://{DROPLET_IP}:8000/health
  Tools:     http://{DROPLET_IP}:8000/mcp/tools
  Run tool:  http://{DROPLET_IP}:8000/mcp/run/{{tool_name}}

SSH Access:
  ssh root@{DROPLET_IP}
  Password: {ROOT_PASSWORD}

Next Steps for Business Owner:

1. Update mcp_stdio_bridge.py:
   Change line 25 from:
     SERVER_URL = "http://localhost:8000"
   To:
     SERVER_URL = "http://{DROPLET_IP}:8000"

2. Restart Claude Desktop

3. Test:
   "Show me my GoHighLevel contacts"
   "Get actionable insights"

For Developer:

1. Access from your computer:
   curl http://{DROPLET_IP}:8000/health
   curl http://{DROPLET_IP}:8000/mcp/tools

2. SSH access:
   ssh root@{DROPLET_IP}

3. View logs:
   ssh root@{DROPLET_IP} 'cd /home/medtainer/medtainer-mcp && docker-compose -f docker-compose.prod.yml logs -f'

4. See DEVELOPER_ACCESS.md for more details

Cost: $24/month
""")


def main():
    """Main deployment flow."""
    print("\n" + "=" * 60)
    print("🚀 MedTainer MCP - Complete Deployment")
    print("=" * 60)

    try:
        # Step 1: Setup server
        if not setup_server():
            print("❌ Server setup failed. Aborting.")
            sys.exit(1)

        # Step 2: Deploy application
        if not deploy_application():
            print("❌ Application deployment failed. Aborting.")
            sys.exit(1)

        # Step 3: Verify deployment
        verify_deployment()

        # Step 4: Print success info
        print_success_info()

        print("✅ Deployment complete! 🎉\n")

    except KeyboardInterrupt:
        print("\n\n❌ Deployment cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
